1. Remove the special charachers
	eq: &_--~#$%^*

2. Remove the additional columns
3. Only use rowdata

4. Asset Condition
	* Good
	* Poor
	* Medium
	* None

5. Asset Type
	* Laptop
	* Desktop
	* Monitor
	* Projector
	* Scanner
	* TAB
	* Pen Drive
	* External Hard Drive
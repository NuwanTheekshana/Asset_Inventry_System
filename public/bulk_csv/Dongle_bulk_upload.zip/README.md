1. Remove the special charachers
	eq: &_--~#$%^*

2. Remove the additional columns
3. Only use rowdata
		